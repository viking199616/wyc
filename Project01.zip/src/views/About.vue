<template>
  <div class="about">
    <h1>{{ id }}</h1>
    <div ref="chart" style="height: 400px; width: 600px;background:red;"></div>
  </div>
</template>
<script>
import echarts from "echarts"
import { reactive, ref, onMounted } from "vue"

export default {
  setup(){       //驱动函数
    const state = reactive({    //创建响应式数据对象
      id: '第一个图表',
      chart: ref()
    });
    const init = () => {    //定义方法
      if (state.chart) {     //图表初始化
      conslut(state.chart);
        var myChart = echarts.init(state.chart);

        const option = {//图表配置数据
          xAxis: {
            type: 'category',
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          },
          yAxis: {
            type: 'value',
          },
          series: [   //具体图表信息
            {         //图表数据
              date: [10, 20, 30, 20, 10, 40, 50], //图表类型
              type: 'line',
            }
          ]
        }
        myChart.setOption(option);  //指定配置项和数据显示
      } //3.0 不能用this
    }
    onMounted(() => {
      init()
    })
    return state;
  }
}
</script>