module.exports = {
  configureWebpack: {
    devtool: 'source-map'
  }
}